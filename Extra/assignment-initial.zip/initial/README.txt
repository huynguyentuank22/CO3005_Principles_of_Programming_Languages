This is version 1.3
Change current directory to initial/src where there is file run.py
Type: python run.py test VMSuite
Change log
- From 1.0
Change minus to sub in vm.pl and VMSuite.py
- From 1.1
Change the type from real to float in test 403 
Change method TestVM.check in TestUtils.py so that it saves input string to files in folder testcases
Add the version of function getAndTest in run.py for the new version of Python
- From 1.2
Break vm.pl into virtual.pl and vm.pl
Change TestUtil.py such that starting from virtual.pl




